/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * JSweeper - the grid based strategy game
 *
 *  Copyright (C) 2005, Neal Clark, Clark Multimedia
 *  http://www.clarkmultimedia.com
 *
 *  Suggestions and comments should be sent to:
 *
 *  nclark@users.sourceforge.net
 *
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package net.sourceforge.jsweeper.view;

import java.awt.BorderLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JLabel;
import javax.swing.JPanel;

import net.sourceforge.jsweeper.controller.Controller;

/**
 * @author neal
 * 
 * Displays the game status including the number of mines left unflagged.
 */
public class StatusBarView extends JPanel
{
    
    private Controller controller;
    /**
     * Creates a new status bar object
     */
    public StatusBarView(Controller controller)
    {
        this.controller = controller;
        initComponents();
    }

    /**
     * Initializes all GUI comporents of the status bar
     */
    private void initComponents()
    {
        super.setLayout(getMineFieldLayout());
        super.add(getMinesLabel(), BorderLayout.WEST);
        
        JPanel panel = new JPanel();
        panel.add(getStatusButton());
        super.add(panel, BorderLayout.CENTER);
        super.add(getTimeLabel(), BorderLayout.EAST);
        
    }

    /**
     * Initializes once and returns a JLabel displaying the number of mines left
     * unflagged
     * 
     * @return
     */
    private JLabel getMinesLabel()
    {
        if (minesLabel == null)
        {
            minesLabel = new JLabel();
            setMineCount(0);
        }

        return minesLabel;
    }
    
    /**
     * @return Loads and returns the status button
     */
    private StatusButton getStatusButton()
    {
        if(statusButton == null)
        {
            statusButton = new StatusButton();
            statusButton.addActionListener(new ActionListener(){

                public void actionPerformed(ActionEvent e)
                {
                    controller.newGame();
                }
                
            });
        }
        
        return statusButton;
    }
    
    /**
     * Ensures the grid layout manager for this mine fiels is initialized and
     * returns it.
     * 
     * @return GridLayout or manage the layout of the buttons.
     */
    private BorderLayout getMineFieldLayout()
    {
        if (layout == null)
        {
            layout = new BorderLayout();
        }

        return layout;
    }
    
    /**
     * @return loads and returns the elapsed time label
     */
    private JLabel getTimeLabel()
    {
        if(timeLabel == null)
        {
            timeLabel = new JLabel("Time: 0");
        }
        
        return timeLabel;
    }
    /**
     * Sets the number of mines being displayed
     * 
     * @param count
     *            Number of mines
     */
    public void setMineCount(int count)
    {
        minesLabel.setText("Mines: " + count);
    }
    
    /**
     *  Displays the normal face
     */
    public void setNormal()
    {
        getStatusButton().setSmile();
    }
    
    /**
     * Displays the mouse down face
     */
    public void setMouseDown()
    {
        getStatusButton().setAah();
    }
    
    /**
     * Displays the game over face
     */
    public void setGameOver()
    {
        getStatusButton().setDead();
    }
    
    /**
     * Displays the game won face
     */
    public void setGameWon()
    {
        getStatusButton().setCool();
    }
    
    /**
     * Sets the elapsed time th game has been played for
     * @param time elapsed time
     */
    public void setTime(int time)
    {
        getTimeLabel().setText("Time: " + time);
    }
    
    private BorderLayout layout = null;

    private JLabel minesLabel = null;
    
    private JLabel timeLabel = null;
    
    private StatusButton statusButton = null;
}