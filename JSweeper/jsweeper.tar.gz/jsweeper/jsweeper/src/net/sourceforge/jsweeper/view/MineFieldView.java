/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * JSweeper - the grid based strategy game
 *
 *  Copyright (C) 2005, Neal Clark, Clark Multimedia
 *  http://www.clarkmultimedia.com
 *
 *  Suggestions and comments should be sent to:
 *
 *  nclark@users.sourceforge.net
 *
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package net.sourceforge.jsweeper.view;

import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import javax.swing.JPanel;

import net.sourceforge.jsweeper.controller.Controller;

/**
 * @author neal
 * 
 * This class provides a visual representation of a mine field containing grid
 * of buttons with the specified number of rows and columns.
 */
public class MineFieldView extends JPanel
{
    public final int ROWS;

    public final int COLS;
    
    public final static String MOUSE_DOWN_EVENT = "MOUSE_DOWN_EVENT";
    
    public final static String MOUSE_UP_EVENT = "MOUSE_UP_EVENT";
    
    private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);

    public Controller controller = null;

    /**
     * Creates a mine field with the specified number of rows and columns. Any
     * right or left mouse clicks will be passed to the new game as
     * revealSquare(..) and flagSquare(..) method calls respectively.
     * 
     * @param rows
     * @param cols
     * @param controller
     */
    public MineFieldView(int rows, int cols, Controller controller)
    {
        this.ROWS = rows;
        this.COLS = cols;
        this.controller = controller;

        initComponents();
    }

    /**
     * Initializes all GUI components
     */
    private void initComponents()
    {
        super.setLayout(getMineFieldLayout());
        getMineField();
    }

    /**
     * Ensures the grid layout manager for this mine fiels is initialized and
     * returns it.
     * 
     * @return GridLayout or manage the layout of the buttons.
     */
    private GridLayout getMineFieldLayout()
    {
        if (layout == null)
        {
            layout = new GridLayout(ROWS, COLS);
        }

        return layout;
    }

    /**
     * Ensures the mineField variable is initialized with an array of butotns
     * containing the number of ros and columns specified in ROWS and COLS
     * repsectively.
     * 
     * @return an initialized array of MineButtons
     */
    private MineButton[][] getMineField()
    {
        if (mineField == null)
        {
            mineField = new MineButton[ROWS][COLS];

            for (int i = 0; i < ROWS; i++)
            {
                for (int j = 0; j < COLS; j++)
                {
                    mineField[i][j] = getMine(i, j);
                    this.add(mineField[i][j]);
                }
            }
        }

        return mineField;
    }

    /**
     * Ensures The mine button at the specified location of the mineField array
     * is initialized. The MineButton is set so that is knows its position in
     * the mineField. This ensures that the revealSquare(...) and
     * flagSquare(...) methods are passed the propper grid locations.
     * 
     * @param row
     *            y coordinate
     * @param col
     *            x coordinate
     * @return Returns the initialized MineButton
     */
    private MineButton getMine(int row, int col)
    {
        if (mineField[row][col] == null)
        {
            MineButton mine = new MineButton(row, col);
            mineField[row][col] = mine;
            mine.addMouseListener(new MouseAdapter()
            {
                public void mouseClicked(MouseEvent e)
                {
                    switch (e.getButton())
                    {
                    case MouseEvent.BUTTON1:
                        controller.revealSquare(((MineButton) e.getSource())
                                .getRow(), ((MineButton) e.getSource())
                                .getCol());
                        break;

                    case MouseEvent.BUTTON3:
                        controller.flagSquare(((MineButton) e.getSource())
                                .getRow(), ((MineButton) e.getSource())
                                .getCol());
                        break;
                    }
                }
                
                public void mousePressed(MouseEvent e)
                {
                    if(e.getButton() == MouseEvent.BUTTON1)
                    {
                        pcs.firePropertyChange(MineFieldView.MOUSE_DOWN_EVENT, e, e.getSource());
                    }
                }
                
                public void mouseReleased(MouseEvent e)
                {
                    if(e.getButton() == MouseEvent.BUTTON1)
                    {
                        pcs.firePropertyChange(MineFieldView.MOUSE_UP_EVENT, e, e.getSource());
                    }
                }
            });
        }

        return mineField[row][col];
    }

    /**
     * If isFlagged is set to true the the MineButton at the specified grid
     * location is marked as flagged
     * 
     * @param row
     *            y coordinate
     * @param col
     *            x coordinate
     * @param isFlagged
     *            A true value results in the MineButton displaying the flaggeD
     *            state
     */
    public void setFlagged(int row, int col, boolean isFlagged)
    {
        getMine(row, col).setFlagged(isFlagged);
    }

    /**
     * Passes the reveal Square code to the MineButton at the specified grid
     * locaiton.
     * 
     * @param row
     *            y coordinate
     * @param col
     *            x coordinate
     * @param status
     *            status code representing the button state.
     */
    public void revealSquare(int row, int col, int status)
    {
        getMineField()[row][col].setRevealed(status);
    }

    /**
     * Resets all the buttons in the MineField to thier defaults.
     */
    public void reset()
    {
        for (int i = 0; i < ROWS; i++)
        {
            for (int j = 0; j < COLS; j++)
            {
                mineField[i][j].reset();
            }
        }
    }
    
    /**
     * Adds a property listener to the model to for property change events
     * 
     * @param pcl
     *            Event Listener
     */
    public void addPropertyChangeListener(PropertyChangeListener pcl)
    {
        pcs.addPropertyChangeListener(pcl);
    }

    /**
     * Adds a property listener to the model to for property change events with
     * the specified name
     * 
     * @param propertyName
     *            Name of signal to listen for
     * @param pcl
     *            Event Listener
     */
    public void addPropertyChangeListener(String propertyName,
            PropertyChangeListener pcl)
    {
        pcs.addPropertyChangeListener(propertyName, pcl);
    }

    /**
     * Removes the specified event listener from the list of registered
     * listeners.
     * 
     * @param pcl
     *            Event Listener
     */
    public void repovePropertyChangeListener(PropertyChangeListener pcl)
    {
        pcs.removePropertyChangeListener(pcl);
    }

    /**
     * Removes the specified event listener from the list of registered
     * listeners.
     * 
     * @param propertyName
     *            Name of signal to listen for
     * @param pcl
     *            Event Listener
     */
    public void repovePropertyChangeListener(String propertyName,
            PropertyChangeListener pcl)
    {
        pcs.removePropertyChangeListener(propertyName, pcl);
    }

    private GridLayout layout = null;

    private MineButton[][] mineField = null;
}