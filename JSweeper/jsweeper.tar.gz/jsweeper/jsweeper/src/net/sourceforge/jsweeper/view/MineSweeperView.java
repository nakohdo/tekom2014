/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * JSweeper - the grid based strategy game
 *
 *  Copyright (C) 2005, Neal Clark, Clark Multimedia
 *  http://www.clarkmultimedia.com
 *
 *  Suggestions and comments should be sent to:
 *
 *  nclark@users.sourceforge.net
 *
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package net.sourceforge.jsweeper.view;

import java.awt.BorderLayout;
import java.awt.Container;
import java.awt.Dimension;
import java.awt.Point;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;

import javax.swing.Box;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.KeyStroke;

import net.sourceforge.jsweeper.controller.Controller;
import net.sourceforge.jsweeper.model.MineSweeperModel;

/**
 * @author neal
 *  
 */
public class MineSweeperView extends JFrame
{

    private int rows;

    private int cols;
    
    private boolean paused = false;

    /**
     * Creates a new MineSweeperView with a fixed number of rows and columns.
     * 
     * @param controller
     *            Game controller
     * @param model
     *            Game model
     */
    public MineSweeperView(Controller controller, MineSweeperModel model, int rows, int cols)
    {
        this.controller = controller;
        this.rows = rows;
        this.cols = cols;
        
        addPropertyChangeListeners(model);

        initComponents();

        // set up window
        super.setTitle("JSweeper");
        super.setIconImage(IconFactory.getIconFactory().getMineIcon()
                .getImage());
        super.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        super.setResizable(false);
        super.setVisible(true);

        controller.newGame();
        
        setSize();
    }
    
    private void setSize()
    {
        super.pack();
        
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int height = (screenSize.height / 2) - (this.getHeight() / 2);
        int width = (screenSize.width / 2) - (this.getWidth() / 2);
        super.setLocation(width, height);
    }

    /**
     * Initializes all GUI compontents and adds them to the inherited JFrame
     */
    private void initComponents()
    {
        Container pane = super.getContentPane();
        super.setJMenuBar(getGameMenuBar());
        
        super.addWindowFocusListener(new WindowAdapter() {

            public void windowLostFocus(WindowEvent e)
            {
                pauseGame();
            }
        });

        pane.setLayout(new BorderLayout());
        pane.add(getStatusBar(), BorderLayout.NORTH);
        pane.add(getMineField(), BorderLayout.CENTER);
    }
    
    private void pauseGame()
    {
        if(!paused && controller.isStarted() && !controller.isGameOver() && !controller.isWon())
        {
            paused = true;
            controller.pause(true);
	        
            String[] options = {"OK"};
	        
	        int n = JOptionPane.showOptionDialog(this,
	                "Click ok to resume game",
	                "Game Paused", JOptionPane.YES_NO_CANCEL_OPTION,
	                JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
	        
	        controller.pause(false);
	        paused = false;
        }
    }

    /**
     * Initializes once and returns a JMenuBar containing File and Help menus
     * with a seperator between them.
     * 
     * @return Initialized menu bar
     */
    private JMenuBar getGameMenuBar()
    {
        if (menuBar == null)
        {
            menuBar = new JMenuBar();
            menuBar.add(getFileMenu());
            menuBar.add(getSettingsMenu());

            // add help menu to right hand side of menubar
            menuBar.add(Box.createHorizontalGlue());
            menuBar.add(getHelpMenu());
        }

        return menuBar;
    }

    /**
     * Initializes once and returns a JMenu representing the File Menu
     * 
     * @return Returns the File Menu
     */
    private JMenu getFileMenu()
    {
        if (fileMenu == null)
        {
            fileMenu = new JMenu("File");
            fileMenu.setMnemonic(KeyEvent.VK_F);

            fileMenu.add(getNewMenuItem());
            fileMenu.addSeparator();
            fileMenu.add(getExitMenuItem());
        }

        return fileMenu;
    }

    /**
     * Initializes once and returns a JMenu representing the Help Menu
     * 
     * @return Returns the Help Menu
     */
    private JMenu getHelpMenu()
    {
        if (helpMenu == null)
        {
            helpMenu = new JMenu("Help");
            helpMenu.setMnemonic(KeyEvent.VK_H);

            helpMenu.add(getAboutMenuItem());
        }

        return helpMenu;
    }

    /**
     * Initializes once and returns a JMenu representing the Settings Menu
     * 
     * @return Returns the Help Menu
     */
    private JMenu getSettingsMenu()
    {
        if (settingsMenu == null)
        {
            settingsMenu = new JMenu("Settings");
            settingsMenu.setMnemonic(KeyEvent.VK_S);

            settingsMenu.add(getPreferencesMenuItem());
        }

        return settingsMenu;
    }

    /**
     * Initializes once and returns a JMenuItem representing the "New Game"
     * option for the file menu
     * 
     * @return Returns the "New Game" menu item
     */
    private JMenuItem getNewMenuItem()
    {
        if (newMenuItem == null)
        {
            newMenuItem = new JMenuItem("New Game");
            newMenuItem.setMnemonic(KeyEvent.VK_N);
            newMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_N,
                    ActionEvent.CTRL_MASK));

            newMenuItem.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent arg0)
                {
                    controller.newGame();
                }

            });
        }

        return newMenuItem;
    }

    /**
     * Initializes once and returns a JMenuItem representing the "Exit" option
     * for the file menu
     * 
     * @return Returns the "Exit" menu item
     */
    private JMenuItem getExitMenuItem()
    {
        if (exitMenuItem == null)
        {
            exitMenuItem = new JMenuItem("Exit", IconFactory.getIconFactory()
                    .getExitIcon());
            exitMenuItem.setMnemonic(KeyEvent.VK_X);
            exitMenuItem.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_Q,
                    ActionEvent.CTRL_MASK));

            exitMenuItem.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent arg0)
                {
                    controller.exitGame();
                }

            });
        }

        return exitMenuItem;
    }

    /**
     * Initializes once and returns a JMenuItem representing the "About" option
     * for the help menu
     * 
     * @return Returns the "About" menu item
     */
    private JMenuItem getAboutMenuItem()
    {
        if (aboutMenuItem == null)
        {
            aboutMenuItem = new JMenuItem("About", IconFactory.getIconFactory()
                    .getAboutIcon());
            aboutMenuItem.setMnemonic(KeyEvent.VK_A);

            aboutMenuItem.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent arg0)
                {
                    showAboutDialog();
                }

            });
        }

        return aboutMenuItem;
    }

    /**
     * Sets up the preferences menu item dialog
     * @return a references to the preferences panel
     */
    private JMenuItem getPreferencesMenuItem()
    {
        if (prefMenuItem == null)
        {
            prefMenuItem = new JMenuItem("Preferences", IconFactory
                    .getIconFactory().getPreferencesIcon());
            prefMenuItem.setMnemonic(KeyEvent.VK_P);
            prefMenuItem.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent arg0)
                {
                    showPreferencesDialog();
                }

            });
        }

        return prefMenuItem;
    }

    /**
     * Displays the "About this software" dialog.
     */
    private void showAboutDialog()
    {
        new AboutDialog(this);
    }
    
    /**
     * Displays the preferences dialog
     */
    private void showPreferencesDialog()
    {
        if(prefsPanel == null)
        {
            prefsPanel = new PreferencesPanel(this, controller);
        }
        
        prefsPanel.setVisible(true);
    }

    /**
     * Initializes once and returns the status bar
     * 
     * @return Returns the status bar
     */
    private StatusBarView getStatusBar()
    {
        if (statusBar == null)
        {
            statusBar = new StatusBarView(controller);
        }

        return statusBar;
    }

    /**
     * Initializes once and returns the MineField containing a grid of mine
     * buttons
     * 
     * @return Returns the mine field
     */
    private MineFieldView getMineField()
    {
        if (mineField == null)
        {
            mineField = new MineFieldView(rows, cols, controller);
        }

        return mineField;
    }

    /**
     * Adds the property change listenrs for the following events -
     * MineSweeperModel.NEW_GAME_EVENT, MineSweeperModel.GAME_LOST_EVENT,
     * MineSweeperModel.FLAG_SQUARE_EVENT, MineSweeperModel.REVEAL_SQUARE_EVENT,
     * MineSweeperModel.DEBUG_PANEL_UPDATE
     * 
     * @param model
     *            the model to register the events with
     */
    private void addPropertyChangeListeners(MineSweeperModel model)
    {

        // add new game listener
        model.addPropertyChangeListener(MineSweeperModel.NEW_GAME_EVENT,
                new PropertyChangeListener()
                {
                    public void propertyChange(PropertyChangeEvent pce)
                    {
                        newGame();
                    }

                });

        // add game lost listener
        model.addPropertyChangeListener(MineSweeperModel.GAME_WON_EVENT,
                new PropertyChangeListener()
                {
                    public void propertyChange(PropertyChangeEvent pce)
                    {
                        gameWon();
                    }

                });

        // add game lost listener
        model.addPropertyChangeListener(MineSweeperModel.GAME_LOST_EVENT,
                new PropertyChangeListener()
                {
                    public void propertyChange(PropertyChangeEvent pce)
                    {
                        gameLost();
                    }

                });

        // add flag square listener
        model.addPropertyChangeListener(MineSweeperModel.FLAG_SQUARE_EVENT,
                new PropertyChangeListener()
                {
                    public void propertyChange(PropertyChangeEvent pce)
                    {
                        Point point = (Point) pce.getOldValue();
                        flagSquare((int) point.getX(), (int) point.getY(),
                                ((Boolean) pce.getNewValue()).booleanValue());
                    }

                });

        // add reveal square event listener
        model.addPropertyChangeListener(MineSweeperModel.REVEAL_SQUARE_EVENT,
                new PropertyChangeListener()
                {
                    public void propertyChange(PropertyChangeEvent pce)
                    {
                        Point point = (Point) pce.getOldValue();
                        revealSquare((int) point.getX(), (int) point.getY(),
                                ((Integer) pce.getNewValue()).intValue());
                    }

                });

        // add mine counter update listener
        model.addPropertyChangeListener(
                MineSweeperModel.MINE_COUNT_CHANGED_EVENT,
                new PropertyChangeListener()
                {
                    public void propertyChange(PropertyChangeEvent pce)
                    {
                        setMineCount(((Integer) pce.getNewValue()).intValue());
                    }

                });
        
        model.addPropertyChangeListener(
                MineSweeperModel.GAME_SIZE_CHANGED_EVENT,
                new PropertyChangeListener()
                {
                    public void propertyChange(PropertyChangeEvent pce)
                    {
                        Dimension d = (Dimension) pce.getNewValue();
                        setGameSize((int) d.getWidth(), (int) d.getHeight());
                    }

                });

        getMineField().addPropertyChangeListener(
                MineFieldView.MOUSE_DOWN_EVENT, new PropertyChangeListener()
                {
                    public void propertyChange(PropertyChangeEvent evt)
                    {
                        getStatusBar().setMouseDown();
                    }
                });

        getMineField().addPropertyChangeListener(MineFieldView.MOUSE_UP_EVENT,
                new PropertyChangeListener()
                {
                    public void propertyChange(PropertyChangeEvent evt)
                    {
                        getStatusBar().setNormal();
                    }
                });
        
        model.addPropertyChangeListener(MineSweeperModel.TIME_CHANGED_EVENT,
                new PropertyChangeListener()
                {
                    public void propertyChange(PropertyChangeEvent evt)
                    {
                        getStatusBar().setTime(((Integer) evt.getNewValue()).intValue());
                    }
                });

    }
    
    /**
     * Changes the size of the game board
     * @param rows rows in new size
     * @param cols cols in new size
     */
    private void setGameSize(int rows, int cols)
    {
        this.rows = rows;
        this.cols = cols;

        Container pane = super.getContentPane();
        pane.remove(getMineField());
        mineField = null;
        pane.add(getMineField(), BorderLayout.CENTER);
        
        setSize();
        
    }

    /**
     * Sets the mine count of the StatusBar object
     * 
     * @param count
     *            number of mines to display
     */
    private void setMineCount(int count)
    {
        getStatusBar().setMineCount(count);
    }

    /**
     * Passes the reveal square message to the specified button in the mine
     * field.
     * 
     * @param row
     *            y coordinate
     * @param col
     *            x coordinate
     * @param status
     *            Status code representing the button state
     */
    private void revealSquare(int row, int col, int status)
    {
        getMineField().revealSquare(row, col, status);
    }

    /**
     * Resets all GUI elements to the new game state
     */
    private void newGame()
    {
        getStatusBar().setNormal();
        getMineField().reset();
    }

    /**
     * Displays the game lost message to the player
     */
    private void gameLost()
    {
        getStatusBar().setGameOver();
        JOptionPane.showMessageDialog(this, "You Lost!", "You Lost!",
                JOptionPane.ERROR_MESSAGE);
    }

    /**
     * Displays the game won message to the player
     */
    private void gameWon()
    {
        getStatusBar().setGameWon();
        JOptionPane.showMessageDialog(this, "You Win!", "You Win!",
                JOptionPane.WARNING_MESSAGE);
    }

    /**
     * Passes the flag square message to the specified button in the mine field.
     * 
     * @param row
     *            y coordinate
     * @param col
     *            x coordinate
     * @param flagged
     *            weather or not the button should display a flag
     */
    private void flagSquare(int row, int col, boolean flagged)
    {
        getMineField().setFlagged(row, col, flagged);
    }

    private Controller controller = null;

    private MineFieldView mineField = null;

    private StatusBarView statusBar = null;

    private JMenuItem newMenuItem = null;

    private JMenuItem exitMenuItem = null;

    private JMenuItem aboutMenuItem = null;

    private JMenuItem prefMenuItem = null;

    private JMenuItem advancedMenuItem = null;

    private JMenu helpMenu = null;

    private JMenu fileMenu = null;

    private JMenu settingsMenu = null;

    private JMenuBar menuBar = null;
    
    private PreferencesPanel prefsPanel = null;

}