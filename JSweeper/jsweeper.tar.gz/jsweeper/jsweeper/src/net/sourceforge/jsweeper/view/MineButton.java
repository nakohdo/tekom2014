/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * JSweeper - the grid based strategy game
 *
 *  Copyright (C) 2005, Neal Clark, Clark Multimedia
 *  http://www.clarkmultimedia.com
 *
 *  Suggestions and comments should be sent to:
 *
 *  nclark@users.sourceforge.net
 *
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package net.sourceforge.jsweeper.view;

import java.awt.Dimension;
import java.awt.Insets;

import javax.swing.JButton;

/**
 * @author nclark@uvic.ca
 * 
 * Represents a grid location in the mine field GUI.
 */
public class MineButton extends JButton
{
    public final static int IS_MINE = -1;

    public final static int HAS_0_ADJACENCIES = 0;

    public final static int HAS_1_ADJACENCIES = 1;

    public final static int HAS_2_ADJACENCIES = 2;

    public final static int HAS_3_ADJACENCIES = 3;

    public final static int HAS_4_ADJACENCIES = 4;

    public final static int HAS_5_ADJACENCIES = 5;

    public final static int HAS_6_ADJACENCIES = 6;

    public final static int HAS_7_ADJACENCIES = 7;

    public final static int HAS_8_ADJACENCIES = 8;
    
    public static final int WIDTH = 25;

    public static final int HEIGHT = 25;

    private int row;

    private int col;

    /**
     * <p>
     * Creates a new mine button for the grid location specified by row and
     * column. The row and column information is stored so that the button can
     * identify itsself when it is clicked.
     * </p>
     * 
     * <p>
     * <b>Warning: </b> there is nothing to stop a programmer from creating a
     * button that contains incorrect grid information or from putting a mine
     * button in an incorrect location.
     * </p>
     * 
     * @param row
     *            Row the mine button be placed in
     * @param col
     *            Column the mine button will be placed in
     */
    public MineButton(int row, int col)
    {
        super();
        super.setMargin(new Insets(0, 0, 0, 0));
        super.setFocusPainted(false);
        super.setFocusable(false);
        super.setRolloverEnabled(false);
        super.setAction(null);
        super.setPreferredSize(new Dimension(WIDTH, HEIGHT));
        
        this.row = row;
        this.col = col;

    }

    /**
     * @return Returns the row the mine button was instantiated to occupy
     */
    public int getRow()
    {
        return row;
    }

    /**
     * @return Returns the column the mine button was instantiated to occupy
     */
    public int getCol()
    {
        return col;
    }

    /**
     * Changes the button to display a flag when the flagged parameter is set to
     * true
     * 
     * @param flagged
     *            true will result in the button displaying the flagged state
     */
    public void setFlagged(boolean flagged)
    {
        if (flagged)
        {
            super.setIcon(IconFactory.getIconFactory().getFlagIcon());
            super.setText("");
        }
        else
        {
            super.setIcon(null);
            super.setText("");
        }
    }

    /**
     * Resets the button to its initial state
     */
    public void reset()
    {
        super.getModel().setPressed(false);
        super.setEnabled(true);
        super.setText("");
        super.setIcon(null);
    }

    /**
     * <p>
     * Sets the button to dispaly one of the following states based on the int
     * passed in
     * <ul>
     * <li>a value of -1 results in a mine being displayed</li>
     * <li>a balue of 0 results in the empty state being displayed</li>
     * <li>a value between 1 and 8 resutls in the specified number being
     * displayed</li>
     * </ul>
     * </p>
     * 
     * <p>
     * <b>Warning: </b> There is not error checking on input values. Any number
     * not mentioned above will simply be displayed on the button.
     * </p>
     * 
     * @param status
     */
    public void setRevealed(int status)
    {
        if (status == IS_MINE)
        {
            super.setText("");
            super.setIcon(IconFactory.getIconFactory().getMineIcon());
        }
        else if(status == HAS_0_ADJACENCIES)
        {
            super.setText("");
            super.setIcon(null);
        }
        else
        {
            super.setText("" + status);
            super.setIcon(null);
        }
        
        super.setEnabled(false);
        super.getModel().setPressed(true);
    }

}