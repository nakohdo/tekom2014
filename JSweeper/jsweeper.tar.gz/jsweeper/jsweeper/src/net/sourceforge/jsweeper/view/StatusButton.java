/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * JSweeper - the grid based strategy game
 *
 *  Copyright (C) 2005, Neal Clark, Clark Multimedia
 *  http://www.clarkmultimedia.com
 *
 *  Suggestions and comments should be sent to:
 *
 *  nclark@users.sourceforge.net
 *
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package net.sourceforge.jsweeper.view;

import java.awt.Dimension;

import javax.swing.JButton;

import net.sourceforge.jsweeper.controller.Controller;

/**
 * @author neal
 *
 */
public class StatusButton extends JButton
{   
    private Controller controller = null;
    
    private int pos;
    
    /**
     * Creates a new status button
     */
    StatusButton()
    {
        initComponents();
    }

    /**
     * Sets up the status button
     */
    private void initComponents()
    {
        super.setPreferredSize(new Dimension(40, 40));
        setSmile();
    }
    
    /**
     * Displays the smile face
     */
    public void setSmile()
    {
        super.setIcon(IconFactory.getIconFactory().getFaceSmileIcon());
    }
    
    /**
     * displays the aah face
     */
    public void setAah()
    {
        super.setIcon(IconFactory.getIconFactory().getFaceAahIcon());
    }
    
    /**
     * displays the cool face
     */
    public void setCool()
    {
        super.setIcon(IconFactory.getIconFactory().getFaceCoolIcon());
    }
    
    /**
     * displays the dead face
     */
    public void setDead()
    {
        super.setIcon(IconFactory.getIconFactory().getFaceDeadIcon());
    }
}
