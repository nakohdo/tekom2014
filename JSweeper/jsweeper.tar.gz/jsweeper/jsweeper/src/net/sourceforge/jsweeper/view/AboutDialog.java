/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * JSweeper - the grid based strategy game
 *
 *  Copyright (C) 2005, Neal Clark, Clark Multimedia
 *  http://www.clarkmultimedia.com
 *
 *  Suggestions and comments should be sent to:
 *
 *  nclark@users.sourceforge.net
 *
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package net.sourceforge.jsweeper.view;

import java.awt.Component;
import java.awt.Dimension;
import java.awt.Point;
import java.io.IOException;

import javax.swing.JDialog;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;

/**
 * @author neal
 * 
 */
public class AboutDialog extends JDialog
{

    /**
     * creates a new about dialog
     * @param frame reference to parent frame
     */
    public AboutDialog(JFrame frame)
    {
        super(frame, true);
        initComponents();
        this.setLocationRelativeTo(frame);
        super.setVisible(true);
    }

    /**
     * Initializes all components
     */
    private void initComponents()
    {
        super.getContentPane().add(getTabbedPane());
        super.setTitle("About JSweeper");
        super.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);
        super.pack();
    }

    /**
     * Sets up the tabbed pane
     * @return the tabbed pane
     */
    private JTabbedPane getTabbedPane()
    {
        if (tabbedPane == null)
        {
            tabbedPane = new JTabbedPane();
            tabbedPane.add("About", getAboutPanel());
            tabbedPane.add("License", getLicensePanel());
        }

        return tabbedPane;
    }

    /**
     * Sets up the license panel
     * @return the liscense panel
     */
    private JScrollPane getLicensePanel()
    {
        if (licensePanel == null)
        {
            licensePanel = new JScrollPane(getLicensePane(),
                    JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                    JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            licensePanel.setPreferredSize(new Dimension(450, 300));
        }
        return licensePanel;
    }

    /**
     * Sets up the license pane
     * @return the license pane
     */
    private JEditorPane getLicensePane()
    {
        if (licensePane == null)
        {
            try
            {
                licensePane = new JEditorPane(
                        AboutDialog.class
                                .getResource("/net/sourceforge/jsweeper/text/gpl.txt"));
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }

            licensePane.setEditable(false);
        }

        return licensePane;
    }
    
    /**
     * Sets up the about panel
     * @return the about panel
     */
    private JScrollPane getAboutPanel()
    {
        if (aboutPanel == null)
        {
            aboutPanel = new JScrollPane(getAboutPane(),
                    JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
                    JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            aboutPanel.setPreferredSize(new Dimension(450, 300));
        }
        return aboutPanel;
    }
    
    /**
     * sets up the about pane
     * @return the about pane
     */
    private JEditorPane getAboutPane()
    {
        if (aboutPane == null)
        {
            try
            {
                aboutPane = new JEditorPane(
                        AboutDialog.class
                                .getResource("/net/sourceforge/jsweeper/text/about.html"));
            }
            catch (IOException e)
            {
                e.printStackTrace();
            }

            aboutPane.setEditable(false);
        }

        return aboutPane;
    }

    /* (non-Javadoc)
     * @see java.awt.Window#setLocationRelativeTo(java.awt.Component)
     */
    public void setLocationRelativeTo(Component c)
    {
        int x;
        int y;

        super.setLocationRelativeTo(c);
        Point p = super.getLocation();
        x = (int) p.getX() - (this.getWidth() / 2);
        x = (int) p.getY() - (this.getHeight() / 2);

        super.setLocation(p);
    }

    /* (non-Javadoc)
     * @see java.awt.Component#setVisible(boolean)
     */
    public void setVisible(boolean isVisible)
    {
        setLocationRelativeTo(super.getParent());
        super.setVisible(isVisible);
    }

    public static void main(String[] args)
    {
        AboutDialog dialog = new AboutDialog(new JFrame());
        dialog.setVisible(true);
        dialog.setDefaultCloseOperation(JDialog.EXIT_ON_CLOSE);
    }

    private JTabbedPane tabbedPane = null;

    private JScrollPane licensePanel = null;

    private JEditorPane licensePane = null;
    
    private JScrollPane aboutPanel = null;

    private JEditorPane aboutPane = null;
}