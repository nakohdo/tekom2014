/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * JSweeper - the grid based strategy game
 *
 *  Copyright (C) 2005, Neal Clark, Clark Multimedia
 *  http://www.clarkmultimedia.com
 *
 *  Suggestions and comments should be sent to:
 *
 *  nclark@users.sourceforge.net
 *
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package net.sourceforge.jsweeper.model;

import java.awt.Dimension;

/**
 * @author neal
 */
class MineFieldModel
{

    private int rows;

    private int cols;

    private int minesLeft;

    private int totalMines;

    private boolean[][] flagged = null;

    private boolean[][] revealed = null;

    private int[][] mineField = null;

    /**
     * Creates a MineFieldModel containting the specified number of rows, colums
     * and mines. Mines are randonly distributed throughout the minefield and
     * adjacencies are calculated.
     * 
     * @param rows
     *            Number of rows of nines in the minefield
     * @param cols
     *            Number of columns of nines in the minefield
     * @param mines
     *            The Number of mines to distribute throughout the minefield
     */
    public MineFieldModel(int rows, int cols, int mines)
    {
        setBoardSize(rows, cols, mines);
    }

    /**
     * Changes the number of rows columns and mines on the game board.
     * 
     * @param rows
     *            Number of rows of nines in the minefield
     * @param cols
     *            Number of columns of nines in the minefield
     * @param mines
     *            The Number of mines to distribute throughout the minefield
     */
    public void setBoardSize(int rows, int cols, int mines)
    {   
        this.rows = rows;
        this.cols = cols;

        this.minesLeft = mines;
        this.totalMines = mines;

        this.mineField = new int[rows + 2][cols + 2];
        this.flagged = new boolean[rows][cols];
        this.revealed = new boolean[rows][cols];
    }

    /**
     * Resets the mine field to its initial state redistributes the mines
     * throughout and then calculated the adjacency numbers.
     */
    public void setup()
    {
        resetMineField(totalMines);
        resetFlaggedValues();
        resetRevealed();

        minesLeft = totalMines;
    }

    /**
     * Unflaggs all of the mines in the minefield
     */
    private void resetFlaggedValues()
    {
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                flagged[i][j] = false;
            }
        }
    }

    /**
     * Resets all of hte squares in the minefield to 0 then redistributes the
     * mines and calculates any adjacencies
     */
    private void resetMineField(int mines)
    {       
        for (int i = 0; i < rows + 2; i++)
        {
            for (int j = 0; j < cols + 2; j++)
            {
                mineField[i][j] = 0;
            }
        }

        setMines(mines);
        calculateAdjacencies();
    }

    /**
     * Populates the mine field with mines
     * 
     * @param mines
     *            number of mines to set
     */
    private void setMines(int mines)
    {
        for (int i = 0; i < mines; i++)
        {
            int row = (int) Math.floor(Math.random() * rows);
            int col = (int) Math.floor(Math.random() * cols);

            if (!isMine(row, col))
            {
                setMine(row, col);
            }
            // if a mine is not placed don't increment mines placed count i
            else
            {
                i--;
            }
        }
    }

    /**
     * Caculates the adjacency number for all squares
     *  
     */
    private void calculateAdjacencies()
    {
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                if (!isMine(i, j))
                {
                    mineField[i + 1][j + 1] = adjacentMines(i, j);
                }
            }
        }
    }

    /**
     * calculates the mines adjacent to a particular square
     * 
     * @param row
     *            row of square
     * @param col
     *            col of square
     * @return
     */
    private int adjacentMines(int row, int col)
    {
        int adj = 0;

        if (isMine(row - 1, col - 1))
            adj++;
        if (isMine(row - 1, col))
            adj++;
        if (isMine(row - 1, col + 1))
            adj++;

        if (isMine(row, col - 1))
            adj++;
        if (isMine(row, col + 1))
            adj++;

        if (isMine(row + 1, col - 1))
            adj++;
        if (isMine(row + 1, col))
            adj++;
        if (isMine(row + 1, col + 1))
            adj++;

        return adj;
    }

    /**
     * Turns a particular square into a mine
     * 
     * @param row
     *            row of the square
     * @param col
     *            col or the square
     */
    private void setMine(int row, int col)
    {
        mineField[row + 1][col + 1] = -1;
    }

    /**
     * Hides all of the squares in the minefield
     */
    private void resetRevealed()
    {
        for (int i = 0; i < rows; i++)
        {
            for (int j = 0; j < cols; j++)
            {
                revealed[i][j] = false;
            }
        }
    }

    /**
     * checks the mine at the specified row and column and returns true if the
     * mine is marked as flagged
     * 
     * @param row
     *            y location of mine
     * @param col
     *            x location of mine
     * @return Returns true if the specified mine is marked as flagged.
     */
    public boolean isFlagged(int row, int col)
    {
        return flagged[row][col];
    }

    /**
     * checks the mine at the specified row and column and returns true if the
     * mine has been previously revealed
     * 
     * @param row
     *            y location of mine
     * @param col
     *            x location of mine
     * @return Returns true if the specified mine has been previously revealed.
     */
    public boolean isRevealed(int row, int col)
    {
        return revealed[row][col];
    }

    /**
     * Returns the number of mines adjacent to the square at the specified grid
     * location
     * 
     * @param row
     *            y location of mine
     * @param col
     *            x location of mine
     * @return Returns the number of mines adjacent to the square at the
     *         specified grid location
     */
    public int getAdjacencies(int row, int col)
    {
        if (!isMine(row, col))
        {
            return mineField[row + 1][col + 1];
        }

        return 0;
    }

    /**
     * Returns the internal representation of a grid location
     * <ul>
     * <li>-1 represents a mine</li>
     * <li>0-8 represent the number of adjacencies</li>
     * </ul>
     * 
     * @param row
     *            y coordinate
     * @param col
     *            x coordinate
     * @return Returns the internal representation of a grid location
     */
    public int getSquareContents(int row, int col)
    {
        return mineField[row + 1][col + 1];
    }

    /**
     * Returns the current number of unflagged mines
     * 
     * @return Returns the current number of unflagged mines
     */
    public int getMineCount()
    {
        return minesLeft;
    }

    /**
     * Reveals the square at the specified location but doesn't check to see if
     * the square has previously been revealed. To ensure consistant behavior
     * user the isRevealed() method to determine if the square has been
     * previously revealed.
     * 
     * @param row
     *            y coordinate
     * @param col
     *            x coordinate
     */
    public void revealSquare(int row, int col)
    {
        revealed[row][col] = true;
    }

    /**
     * If the specified square has not been flagged then the square is flagged
     * and the number of mines is decremented. If the square has already been
     * flagged then the flag is removed and number of mines left is increased by
     * 1.
     * 
     * @param row
     *            y coordinate
     * @param col
     *            x coordinate
     */
    public void flagSquare(int row, int col)
    {
        flagged[row][col] = !flagged[row][col];

        if (flagged[row][col])
        {
            minesLeft--;
        }
        else
        {
            minesLeft++;
        }
    }

    /**
     * This method determines is the specified grid location contains a mine and
     * returns true if it does.
     * 
     * @param row
     *            y coordinate
     * @param col
     *            x coordinate
     * @return Returns true if the grid location contains a mine
     */
    public boolean isMine(int row, int col)
    {
        return mineField[row + 1][col + 1] == -1;
    }

    /**
     * Returns the number of mines minus the number of flags. It is possible to
     * have more flags than mines and in this case a negative number is
     * returned.
     * 
     * @return number of mines not yet flagged
     */
    public int getNumberOfMines()
    {
        return totalMines;
    }

    /**
     * @return Returns the number of columns.
     */
    public int getCols()
    {
        return cols;
    }
    /**
     * @return Returns the of rows.
     */
    public int getRows()
    {
        return rows;
    }
    
    /**
     * Returns the size of the game board
     * @return size of game board
     */
    public Dimension getBoardDimensions()
    {
        return new Dimension(rows, cols);
        
    }

}