/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * JSweeper - the grid based strategy game
 *
 *  Copyright (C) 2005, Neal Clark, Clark Multimedia
 *  http://www.clarkmultimedia.com
 *
 *  Suggestions and comments should be sent to:
 *
 *  nclark@users.sourceforge.net
 *
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package net.sourceforge.jsweeper.view;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.Point;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;

import javax.swing.BorderFactory;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JSeparator;

import net.sourceforge.jsweeper.controller.Controller;

/**
 * @author neal
 * 
 */
public class PreferencesPanel extends JDialog
{
    Controller controller = null;

    /**
     * Creates a new preferences panel which attached to its parent frame
     * @param frame frame to attach the preferences panel to
     * @param controller calls resize game method
     */
    public PreferencesPanel(JFrame frame, Controller controller)
    {
        super(frame, true);
        this.controller = controller;
        initComponents();
        setLocationRelativeTo(frame);
    }

    /**
     *  Initialize all components
     */
    private void initComponents()
    {
        super.setTitle("JSweeper Preferences");

        JPanel panel = new JPanel();
        panel.setLayout(new BorderLayout());

        panel.add(getSizePanel(), BorderLayout.CENTER);
        panel.add(getClosePanel(), BorderLayout.SOUTH);

        panel.setPreferredSize(new Dimension(320, 160));
        
        super.getContentPane().add(panel);

        super.setResizable(false);
        super.pack();
        
    }

    /**
     * @return the button panel to hold small, medium, and large radio buttons
     */
    private JPanel getButtonPanel()
    {
        if (buttonPanel == null)
        {
            buttonPanel = new JPanel();

            buttonPanel.setLayout(new GridLayout(4, 1));

            buttonPanel.add(getBoardSizeLabel());
            buttonPanel.add(getSmallButton());
            buttonPanel.add(getMediumButton());
            buttonPanel.add(getLargeButton());
        }

        return buttonPanel;
    }

    /**
     * @return buttonGroup to manage small, meduim, and large radio buttons
     */
    private ButtonGroup getButtonGroup()
    {
        if (buttonGroup == null)
        {
            buttonGroup = new ButtonGroup();
        }

        return buttonGroup;
    }

    /**
     * @return creates the small button
     */
    private JRadioButton getSmallButton()
    {
        if (smallButton == null)
        {
            smallButton = new JRadioButton("Small");
            smallButton.setMnemonic(KeyEvent.VK_S);
            smallButton.setSelected(true);
            smallButton.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent arg0)
                {
                    controller.setGameSize(9, 9, 10);
                }
            });

            getButtonGroup().add(smallButton);
        }

        return smallButton;
    }

    /**
     * @return creates the meduim button
     */
    private JRadioButton getMediumButton()
    {
        if (mediumButton == null)
        {
            mediumButton = new JRadioButton("Medium");
            mediumButton.setMnemonic(KeyEvent.VK_M);
            mediumButton.setSelected(true);
            mediumButton.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent arg0)
                {
                    controller.setGameSize(16, 16, 40);
                }
            });

            getButtonGroup().add(mediumButton);
        }

        return mediumButton;
    }

    /**
     * @return Creates the large button
     */
    private JRadioButton getLargeButton()
    {
        if (largeButton == null)
        {
            largeButton = new JRadioButton("Large");
            largeButton.setMnemonic(KeyEvent.VK_L);
            largeButton.setSelected(true);
            largeButton.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent arg0)
                {
                    controller.setGameSize(16, 30, 90);
                }
            });

            getButtonGroup().add(largeButton);
        }

        return largeButton;
    }

    /**
     * @return board size label
     */
    private JLabel getBoardSizeLabel()
    {
        if (boardSizeLabel == null)
        {
            boardSizeLabel = new JLabel("Board Size");
        }

        return boardSizeLabel;
    }

    /**
     * @return the close button
     */
    private JButton getCloseButton()
    {
        if (closeButton == null)
        {
            closeButton = new JButton("Close");
            closeButton.setMnemonic(KeyEvent.VK_C);
            closeButton.addActionListener(new ActionListener()
            {
                public void actionPerformed(ActionEvent arg0)
                {
                    close();
                }
            });
        }

        return closeButton;
    }
    
    /**
     * Closes the preferences panel
     */
    private void close()
    {
        super.setVisible(false);
        
    }

    /**
     * @return JPanel to position the close button
     */
    private JPanel getClosePanel()
    {
        if (closePanel == null)
        {
            closePanel = new JPanel();
            FlowLayout layout = new FlowLayout(FlowLayout.RIGHT);
            closePanel.setLayout(layout);
            closePanel.add(getCloseButton());
        }

        return closePanel;
    }

    /**
     * @return panel to position the size buttons
     */
    private JPanel getSizePanel()
    {
        if (sizePanel == null)
        {
            sizePanel = new JPanel();
            sizePanel.setBorder(BorderFactory.createTitledBorder("Difficulty"));
            sizePanel.setLayout(new FlowLayout(FlowLayout.LEFT));
            sizePanel.add(getButtonPanel());
            sizePanel.add(new JSeparator());
        }

        return sizePanel;
    }
    
    /* (non-Javadoc)
     * @see java.awt.Window#setLocationRelativeTo(java.awt.Component)
     */
    public void setLocationRelativeTo(Component c)
    {
        int x;
        int y;
        
        super.setLocationRelativeTo(c);
        Point p = super.getLocation();
        x = (int) p.getX() - (this.getWidth() / 2);
        x = (int) p.getY() - (this.getHeight() / 2);
        
        super.setLocation(p);
    }
    
    /* (non-Javadoc)
     * @see java.awt.Component#setVisible(boolean)
     */
    public void setVisible(boolean isVisible)
    {
        setLocationRelativeTo(super.getParent());
        super.setVisible(isVisible);
    }

    private JPanel sizePanel = null;

    private JPanel buttonPanel = null;

    private ButtonGroup buttonGroup = null;

    private JRadioButton smallButton = null;

    private JRadioButton mediumButton = null;

    private JRadioButton largeButton = null;

    private JLabel boardSizeLabel = null;

    private JPanel closePanel = null;

    private JButton closeButton = null;
}