/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * JSweeper - the grid based strategy game
 *
 *  Copyright (C) 2005, Neal Clark, Clark Multimedia
 *  http://www.clarkmultimedia.com
 *
 *  Suggestions and comments should be sent to:
 *
 *  nclark@users.sourceforge.net
 *
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package net.sourceforge.jsweeper.view;

import javax.swing.ImageIcon;

/**
 * @author neal
 *
 */
public class IconFactory
{
    private static final String ICON_PATH = "/net/sourceforge/jsweeper/images/";
    
    private static IconFactory factory = null;
    
    private IconFactory()
    {
        
    }
    
    /**
     * Creates a new icon factory to manage icon files
     * @return
     */
    static IconFactory getIconFactory()
    {
        if(factory == null)
        {
            factory = new IconFactory();
        }
        
        return factory;
    }
    
    /**
     * @return the exit icon
     */
    public ImageIcon getExitIcon()
    {
        if(exitIcon == null)
        {
            exitIcon = createImageIcon("exit.png");
        }
        
        return exitIcon;
    }
    
    /**
     * @return the about icon
     */
    public ImageIcon getAboutIcon()
    {
        if(aboutIcon == null)
        {
            aboutIcon = createImageIcon("about.png");
        }
        
        return aboutIcon;
    }
    
    /**
     * @return the preferences icon
     */
    public ImageIcon getPreferencesIcon()
    {
        if(prefIcon == null)
        {
            prefIcon = createImageIcon("preferences.png");
        }
        
        return prefIcon;
    }
    
    /**
     * @return the smile icon
     */
    public ImageIcon getFaceSmileIcon()
    {
        if(faceSmileIcon == null)
        {
            faceSmileIcon = createImageIcon("face-smile.png");
        }
        
        return faceSmileIcon;
    }
    
    /**
     * @return the Aah fase icon
     */
    public ImageIcon getFaceAahIcon()
    {
        if(faceAahIcon == null)
        {
            faceAahIcon = createImageIcon("face-aah.png");
        }
        
        return faceAahIcon;
    }
    
    /**
     * @return the cool icon
     */
    public ImageIcon getFaceCoolIcon()
    {
        if(faceCoolIcon == null)
        {
            faceCoolIcon = createImageIcon("face-cool.png");
        }
        
        return faceCoolIcon;
    }
    
    /**
     * @return the dead face icon
     */
    public ImageIcon getFaceDeadIcon()
    {
        if(faceDeadIcon == null)
        {
            faceDeadIcon = createImageIcon("face-saint.png");
        }
        
        return faceDeadIcon;
    }
    
    /**
     * @return the mine icon
     */
    public ImageIcon getMineIcon()
    {
        if(mineIcon == null)
        {
            mineIcon = createImageIcon("mine.png");
        }
        
        return mineIcon;
    }
    
    /**
     * @return the flag icon
     */
    public ImageIcon getFlagIcon()
    {
        if(flagIcon == null)
        {
            flagIcon = createImageIcon("flag.png");
        }
        
        return flagIcon;
    }
    
    /**
     * Helper method to load the icons from file
     * @param path path within the jar file to the images
     * @return created icon
     */
    private static ImageIcon createImageIcon(String path) {
        java.net.URL imgURL = StatusButton.class.getResource(ICON_PATH + path);
        return new ImageIcon(imgURL);
    }
    
    private static ImageIcon exitIcon = null;
    
    private static ImageIcon aboutIcon = null;
    
    private static ImageIcon prefIcon = null;
    
    private static ImageIcon faceSmileIcon = null;
    
    private static ImageIcon faceAahIcon = null;
    
    private static ImageIcon faceCoolIcon = null;
    
    private static ImageIcon faceDeadIcon = null;
    
    private static ImageIcon mineIcon = null;
    
    private static ImageIcon flagIcon = null;
}
