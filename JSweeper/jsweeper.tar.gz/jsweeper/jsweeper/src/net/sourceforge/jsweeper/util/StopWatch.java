/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * JSweeper - the grid based strategy game
 *
 *  Copyright (C) 2005, Neal Clark, Clark Multimedia
 *  http://www.clarkmultimedia.com
 *
 *  Suggestions and comments should be sent to:
 *
 *  nclark@users.sourceforge.net
 *
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package net.sourceforge.jsweeper.util;

import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;
import java.util.Timer;
import java.util.TimerTask;

/**
 * @author neal
 * 
 */
public class StopWatch
{
    private final static int SECOND = 1000;
    
    public final static String TIME_CHANGED_EVENT = "TIME_CHANGED_EVENT";
    
    private Timer timer = null;

    private boolean isStopped = true;
    
    private boolean isPaused = false;

    private int time = 0;
    
    private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);

    /**
     * Returns the elapsed time in seconds
     * @return seconds
     */
    public int getElapsedTime()
    {
        return time;
    }

    /**
     * Resets and starts the stop watch the time is update every 1000 milli seconds
     */
    public void start()
    {
        if(isStopped)
        {
	        isStopped = false;
	        isPaused = false;
	        time = 0;
	        
	        timer = new Timer();
	        timer.schedule(new RemindTask(), 0, 1 * SECOND);
        }
        else
        {
            throw new IllegalStateException();
        }
    }

    /**
     * Stops the stop watch
     */
    public void stop()
    {
        isStopped = true;
    }

    /**
     * Determines if the timer is running
     * @return returns true if the time is stopped
     */
    public boolean isStopped()
    {
        return isStopped;
    }
    
    /**
     * Resets the stop watch
     */
    public void reset()
    {
        isStopped = true;
        int oldTime = time;
        pcs.firePropertyChange(TIME_CHANGED_EVENT, oldTime, 0);
    }
    
    /**
     * Pauses the stop watch temporarily
     * 
     * @param paused set to true to pause the stopwatch
     */
    public void pause(boolean paused)
    {
        isPaused = paused;
    }
    
    public boolean isPaused()
    {
        return isPaused;
    }
    
    /**
     * Updated the elapsed time
     */
    private void updateTime()
    {
        if(!isPaused())
        {
	        int oldTime = time;
	        time++;
	        pcs.firePropertyChange(TIME_CHANGED_EVENT, oldTime, time);
    	}
    }
    
    /**
     * Adds a property listener to the model to for property change events
     * 
     * @param pcl
     *            Event Listener
     */
    public void addPropertyChangeListener(PropertyChangeListener pcl)
    {
        pcs.addPropertyChangeListener(pcl);
    }

    /**
     * Adds a property listener to the model to for property change events with
     * the specified name
     * 
     * @param propertyName
     *            Name of signal to listen for
     * @param pcl
     *            Event Listener
     */
    public void addPropertyChangeListener(String propertyName,
            PropertyChangeListener pcl)
    {
        pcs.addPropertyChangeListener(propertyName, pcl);
    }

    /**
     * Removes the specified event listener from the list of registered
     * listeners.
     * 
     * @param pcl
     *            Event Listener
     */
    public void repovePropertyChangeListener(PropertyChangeListener pcl)
    {
        pcs.removePropertyChangeListener(pcl);
    }

    /**
     * Removes the specified event listener from the list of registered
     * listeners.
     * 
     * @param propertyName
     *            Name of signal to listen for
     * @param pcl
     *            Event Listener
     */
    public void repovePropertyChangeListener(String propertyName,
            PropertyChangeListener pcl)
    {
        pcs.removePropertyChangeListener(propertyName, pcl);
    }

    
    /**
     * @author neal
     *
     * Timer task to update the stop watch
     */
    class RemindTask extends TimerTask
    {

        public void run()
        {
            
            if (!isStopped())
            {
                updateTime();
            }
            else
            {
                timer.cancel();
            }
        }
    }
}