/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * JSweeper - the grid based strategy game
 *
 *  Copyright (C) 2005, Neal Clark, Clark Multimedia
 *  http://www.clarkmultimedia.com
 *
 *  Suggestions and comments should be sent to:
 *
 *  nclark@users.sourceforge.net
 *
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package net.sourceforge.jsweeper.model;

/**
 * @author neal
 */
public interface Model
{

    /**
     * Starts a new game of minesweeper and notifies any observers of the
     * changes to the model
     */
    public void newGame();

    /**
     * Changes the number of rows columns and mines on the game board.
     * 
     * @param rows
     *            Number of rows of nines in the minefield
     * @param cols
     *            Number of columns of nines in the minefield
     * @param mines
     *            The Number of mines to distribute throughout the minefield
     */
    public void setGameSize(int rows, int cols, int mines);
    
    
    /**
     * Reveals the square at the specified location, if a mine is found the
     * gameover message is raised otherwise the square is revealed if the square
     * has no adjacencies then any other adjacent squares which are not mines
     * are also revealed. If the revealSquare method is invoked for a square
     * which has already been revealed then the message is ignored.
     * 
     * @param row
     *            y position of mine
     * @param col
     *            x position pf mine
     */
    public void revealSquare(int row, int col);

    /**
     * Marks the specified square with a flag. If the square is already flagged
     * then the flag is removed. Any observers of the modified square are
     * notified.
     * 
     * @param row
     *            y position of mine
     * @param col
     *            x position pf mine
     */
    public void flagSquare(int row, int col);

    /**
     * determines if the game has been lost.
     * 
     * @return return true if the game is lost
     */
    public boolean isGameOver();

    /**
     * determines if the game has been won
     * 
     * @return returns true if the game has been won
     */
    public boolean isWon();
    
    /**
     * @return returns true if the game has been started
     */
    public boolean isStarted();
    
    /**
     * Pauses and unpauses the game
     * 
     * @param paused set to true to pause the game
     */
    public void pause(boolean paused);

}