/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * JSweeper - the grid based strategy game
 *
 *  Copyright (C) 2005, Neal Clark, Clark Multimedia
 *  http://www.clarkmultimedia.com
 *
 *  Suggestions and comments should be sent to:
 *
 *  nclark@users.sourceforge.net
 *
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package net.sourceforge.jsweeper.controller;

import net.sourceforge.jsweeper.model.MineSweeperModel;
import net.sourceforge.jsweeper.model.Model;
import net.sourceforge.jsweeper.view.MineSweeperView;

/**
 * @author neal
 * 
 * Implements the controller part of the MVC architecture. When invoded the
 * methods of this class directly modify the MineSweeperModel.
 */
public class Controller implements Model
{
    private int ROWS;

    private int COLS;
    
    private int MINES;

    private MineSweeperModel model = null;
    private MineSweeperView view = null;
    
    /**
     * Default constructor creates a new 9x9 game of minesweeper with 15 mines.
     * The controller coordinates the major interactions between the
     * MineSweeperView and the MineSweeperModel.
     * 
     * @param model
     *            the model the controller should modify
     */
    public Controller()
    {
        this.ROWS = 9;
        this.COLS = 9;
        this.MINES = 10;
        
        model = new MineSweeperModel(ROWS, COLS, MINES);
        view = new MineSweeperView(this, model, ROWS, COLS);
    }

    /**
     * When invoked this method starts a new game of minesweeper.
     */
    public void newGame()
    {
        model.newGame();
    }

    /**
     * Caused the minesweeper game to exit
     */
    public void exitGame()
    {
        model = null;
        view = null;

        System.exit(0);
    }

    /**
     * This Method will reveal a square in the minefield if the square has not
     * already been revealed.
     * 
     * @param row
     *            y coordinate of the mine in the mine field
     * @param col
     *            x coordinate of the mine in the mine field
     */
    public void revealSquare(int row, int col)
    {
        if(!model.isWon())
        {
            model.revealSquare(row, col);
        }
    }

    /**
     * Flags a square in the mine field and decrements the number of mines
     * remaining.
     * 
     * @param row
     * @param col
     */
    public void flagSquare(int row, int col)
    {
        if(!model.isWon())
        {
            model.flagSquare(row, col);
        }
    }
    
    /* (non-Javadoc)
     * @see net.sourceforge.jsweeper.model.Model#setGameSize(int, int, int)
     */
    public void setGameSize(int rows, int cols, int mines)
    {
        model.setGameSize(rows, cols, mines);
    }

    /* (non-Javadoc)
     * @see net.sourceforge.jsweeper.model.Model#isGameOver()
     */
    public boolean isGameOver()
    {
        return model.isGameOver();
    }

    /* (non-Javadoc)
     * @see net.sourceforge.jsweeper.model.Model#isWon()
     */
    public boolean isWon()
    {
        return model.isWon();
    }
    
    public static void main(String[] args)
    {
        new Controller();
    }

    /* (non-Javadoc)
     * @see net.sourceforge.jsweeper.model.Model#pauseGame(boolean)
     */
    public void pause(boolean paused)
    {
        model.pause(paused);
        
    }

    /* (non-Javadoc)
     * @see net.sourceforge.jsweeper.model.Model#isStarted()
     */
    public boolean isStarted()
    {
        return model.isStarted();
    }
}