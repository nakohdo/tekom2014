/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * JSweeper - the grid based strategy game
 *
 *  Copyright (C) 2005, Neal Clark, Clark Multimedia
 *  http://www.clarkmultimedia.com
 *
 *  Suggestions and comments should be sent to:
 *
 *  nclark@users.sourceforge.net
 *
 *
 * This program is free software; you can redistribute it and/or
 * modify it under the terms of the GNU General Public License
 * as published by the Free Software Foundation; either version 2
 * of the License, or (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA  02111-1307, USA.
 *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

package net.sourceforge.jsweeper.model;

import java.awt.Point;
import java.beans.PropertyChangeEvent;
import java.beans.PropertyChangeListener;
import java.beans.PropertyChangeSupport;

import net.sourceforge.jsweeper.util.StopWatch;

/**
 * @author neal
 *  
 */
public class MineSweeperModel implements Model
{
    public final static String NEW_GAME_EVENT = "NEW_GAME_EVENT";

    public final static String REVEAL_SQUARE_EVENT = "REVEAL_SQUARE_EVENT";

    public final static String FLAG_SQUARE_EVENT = "FLAG_SQUQRE_EVENT";

    public final static String GAME_LOST_EVENT = "GAME_LOST_EVENT";

    public final static String GAME_WON_EVENT = "GAME_WON_EVENT";

    public final static String MINE_COUNT_CHANGED_EVENT = "MINE_COUNT_CHANGED_EVENT";
    
    public final static String GAME_SIZE_CHANGED_EVENT = "GAME_SIZE_CHANGED_EVENT";
    
    public final static String TIME_CHANGED_EVENT = "TIME_CHANGED_EVENT";

    private final PropertyChangeSupport pcs = new PropertyChangeSupport(this);

    private MineFieldModel mineField = null;

    private boolean isGameOver;
    
    private StopWatch stopWatch = null;
    
    private boolean isStarted = false;

    private boolean isWon;

    /**
     * This class implements the game logic behind the minesweeper game. When
     * calle this method creates a mine sweeper model with the specigfied number
     * of rows and columns and then distributes the specified number of mines
     * throughout the minefield.
     * 
     * @param rows
     *            number of rows of mines
     * @param cols
     *            number of columns of mines
     * @param mines
     *            number of mines to distribute throughout the minefield
     */
    public MineSweeperModel(int rows, int cols, int mines)
    {
        mineField = new MineFieldModel(rows, cols, mines);
        stopWatch = new StopWatch();
        stopWatch.addPropertyChangeListener(StopWatch.TIME_CHANGED_EVENT, new PropertyChangeListener() {

            public void propertyChange(PropertyChangeEvent evt)
            {
                updateTimer(((Integer) evt.getOldValue()).intValue() ,((Integer) evt.getNewValue()).intValue());
            }
            
        });
    }

    /**
     * Adds a property listener to the model to for property change events
     * 
     * @param pcl
     *            Event Listener
     */
    public void addPropertyChangeListener(PropertyChangeListener pcl)
    {
        pcs.addPropertyChangeListener(pcl);
    }

    /**
     * Adds a property listener to the model to for property change events with
     * the specified name
     * 
     * @param propertyName
     *            Name of signal to listen for
     * @param pcl
     *            Event Listener
     */
    public void addPropertyChangeListener(String propertyName,
            PropertyChangeListener pcl)
    {
        pcs.addPropertyChangeListener(propertyName, pcl);
    }

    /**
     * Removes the specified event listener from the list of registered
     * listeners.
     * 
     * @param pcl
     *            Event Listener
     */
    public void repovePropertyChangeListener(PropertyChangeListener pcl)
    {
        pcs.removePropertyChangeListener(pcl);
    }

    /**
     * Removes the specified event listener from the list of registered
     * listeners.
     * 
     * @param propertyName
     *            Name of signal to listen for
     * @param pcl
     *            Event Listener
     */
    public void repovePropertyChangeListener(String propertyName,
            PropertyChangeListener pcl)
    {
        pcs.removePropertyChangeListener(propertyName, pcl);
    }

    /*
     * (non-Javadoc)
     * 
     * @see ca.uvic.seng271.nclark.minesweeper.model.Model#newGame()
     */
    public void newGame()
    {
        mineField.setup();
        setGameOver(false);
        setWon(false);

        // fire new game event
        pcs.firePropertyChange(MineSweeperModel.NEW_GAME_EVENT, null, null);

        // fire mine count changed event
        pcs.firePropertyChange(MineSweeperModel.MINE_COUNT_CHANGED_EVENT, 0,
                mineField.getMineCount());
        
        stopWatch.reset();
    }
    
    /* (non-Javadoc)
     * @see net.sourceforge.jsweeper.model.Model#setGameSize(int, int, int)
     */
    public void setGameSize(int rows, int cols, int mines)
    {
        mineField.setBoardSize(rows, cols, mines);
        pcs.firePropertyChange(MineSweeperModel.GAME_SIZE_CHANGED_EVENT, null, mineField.getBoardDimensions());
        
        newGame();
    }

    /*
     * (non-Javadoc)
     * 
     * @see ca.uvic.seng271.nclark.minesweeper.model.Model#revealSquare(int,
     *      int)
     */
    public void revealSquare(int row, int col)
    {
        // start timer
        if(stopWatch.isStopped())
        {
            stopWatch.start();
        }
        
        // reveal square only if the square is not revealed and not flagged
        if (!mineField.isRevealed(row, col) && !mineField.isFlagged(row, col))
        {
            // if its not a mine reveal
            if (!mineField.isMine(row, col))
            {

                mineField.revealSquare(row, col);
                Point point = new Point(row, col);

                // fire flagged reveal event
                pcs.firePropertyChange(MineSweeperModel.REVEAL_SQUARE_EVENT,
                        point, new Integer(mineField
                                .getSquareContents(row, col)));

                // if adjacencies == 0 reveal surrounding non flaged non mine
                // squares
                if (mineField.getSquareContents(row, col) == 0)
                {
                    revealAdjacent(row, col);
                }
                
                if (checkIsWon())
                {
                    gameWon();
                }
            }
            // if the square is a mine enter game won state
            else
            {
                gameOver();
            }
        }

    }

    /**
     * Reveals adjacent squares, call the reveal square method to revale any appropriate adjacent squares
     * @param row row of square
     * @param col col of square
     */
    private void revealAdjacent(int row, int col)
    {
        // check up
        if (row > 0 && col >= 0)
        {
            if (mineField.getSquareContents(row - 1, col) != -1)
            {
                revealSquare(row - 1, col);
            }
        }
        
        // check up left
        if(row > 0 && col > 0)
        {
            if(mineField.getSquareContents(row - 1, col - 1) != -1)
            {
                revealSquare(row - 1, col -1);
            }
        }
        
        // check up right
        if(row > 0 && col < mineField.getCols() - 1)
        {
            if(mineField.getSquareContents(row - 1, col + 1) != -1)
            {
                revealSquare(row - 1, col + 1);
            }
        }

        // check left
        if (row >= 0 && col > 0)
        {
            if (mineField.getSquareContents(row, col - 1) != -1)
            {
                revealSquare(row, col - 1);
            }
        }

        // check right
        if (row >= 0 && col < mineField.getCols() - 1)
        {
            if (mineField.getSquareContents(row, col + 1) != -1)
            {
                revealSquare(row, col + 1);
            }
        }

        // check down
        if (row < mineField.getRows() - 1 && col >= 0)
        {
            if (mineField.getSquareContents(row, col - 1) != -1)
            {
                revealSquare(row + 1, col);
            }
        }
        
        // check down right
        if(row < mineField.getRows() - 1 && col < mineField.getCols() - 1)
        {
            if(mineField.getSquareContents(row + 1, col + 1) != -1)
            {
                revealSquare(row + 1, col + 1);
            } 
        }
        
        // check down left
        if(row < mineField.getRows() - 1 && col > 0)
        {
            if(mineField.getSquareContents(row + 1, col - 1) != -1)
            {
                revealSquare(row + 1, col -1);
            }
        }
    }

    /*
     * (non-Javadoc)
     * 
     * @see ca.uvic.seng271.nclark.minesweeper.model.Model#flagSquare(int, int)
     */
    public void flagSquare(int row, int col)
    {
        // start timer
        if(stopWatch.isStopped())
        {
            stopWatch.start();
        }
        
        if (!mineField.isRevealed(row, col))
        {
            Point point = new Point(row, col);

            int oldCount = mineField.getMineCount();
            mineField.flagSquare(row, col);

            // fire flagged square event
            pcs.firePropertyChange(MineSweeperModel.FLAG_SQUARE_EVENT, point,
                    new Boolean(mineField.isFlagged(row, col)));

            // fire mine count changed event
            pcs.firePropertyChange(MineSweeperModel.MINE_COUNT_CHANGED_EVENT,
                    oldCount, mineField.getMineCount());
            
            if (checkIsWon())
            {
                gameWon();

            }
        }

    }

    /*
     * (non-Javadoc)
     * 
     * @see ca.uvic.seng271.nclark.minesweeper.model.Model#isGameOver()
     */
    public boolean isGameOver()
    {
        return isGameOver;
    }

    /*
     * (non-Javadoc)
     * 
     * @see ca.uvic.seng271.nclark.minesweeper.model.Model#isWon()
     */
    public boolean isWon()
    {
        return this.isWon;
    }

    /**
     * Check the mine field to determine if the game has been won
     * @return true if the game has been won
     */
    private boolean checkIsWon()
    {
        int count = 0;
        
        for (int i = 0; i < mineField.getRows(); i++)
        {
            for (int j = 0; j < mineField.getCols(); j++)
            {
                // if not a revealed and not a mine game not won
                if(!mineField.isRevealed(i, j) && !mineField.isMine(i, j))
                {
                    return false;
                }
                
                if (!mineField.isRevealed(i, j) && mineField.isMine(i, j) && mineField
                        .isFlagged(i, j))
                {
                    count++;
                }
            }
        }

        return count == mineField.getNumberOfMines();
    }
    
    /**
     * Called when the game has been won and notifies the view
     *
     */
    private void gameWon()
    {
        if(!isWon())
        {
	        setWon(true);
	        stopWatch.stop();
	        
	        pcs.firePropertyChange(MineSweeperModel.GAME_WON_EVENT,
	                1, (int) Math.random() * 100);
        }
    }

    /**
     * Called when a game has been lost
     *
     */
    private void gameOver()
    {
        if(!isGameOver())
        {
	        stopWatch.stop();
	        setGameOver(true);
	        revealAll();
	
	        pcs.firePropertyChange(MineSweeperModel.GAME_LOST_EVENT, 0, 1);
        }

    }

    /**
     * Reveals all squares called when a game has been lost
     *
     */
    private void revealAll()
    {
        for (int i = 0; i < mineField.getRows(); i++)
        {
            for (int j = 0; j < mineField.getCols(); j++)
            {
                if (!mineField.isRevealed(i, j))
                {
                    mineField.revealSquare(i, j);
                    Point point = new Point(i, j);
                    pcs.firePropertyChange(
                            MineSweeperModel.REVEAL_SQUARE_EVENT, point,
                            new Integer(mineField.getSquareContents(i, j)));
                }
            }
        }
    }

    /**
     * sets the gameover status to the value of status
     * @param status true to enter gameover state
     */
    private void setGameOver(boolean status)
    {
        this.isGameOver = status;
    }

    /**
     * set the game won status
     * @param status set to true if the game has been won
     */
    private void setWon(boolean status)
    {
        this.isWon = status;
    }
    
    /**
     * Notifies observers that the timer value has changed 
     * @param oldTime Old time
     * @param newTime New time
     */
    private void updateTimer(int oldTime, int newTime)
    {
        pcs.firePropertyChange(
                MineSweeperModel.TIME_CHANGED_EVENT, oldTime,
                newTime);
        
    }

    /* (non-Javadoc)
     * @see net.sourceforge.jsweeper.model.Model#pauseGame(boolean)
     */
    public void pause(boolean paused)
    {
        stopWatch.pause(paused);
    }

    /* (non-Javadoc)
     * @see net.sourceforge.jsweeper.model.Model#isStarted()
     */
    public boolean isStarted()
    {
        return !stopWatch.isStopped();
    }
    
}